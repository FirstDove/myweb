 $(function(){
	      var $category = $("#replyFrame");//获取需要的对象,:not(:selector)不能直接与:eq(index)合用，但是可以与:last合用；
	      $category.hide();//调用隐藏方法
		  var $toggleBtn = $("#rightBarOne > .newDiscuss");//获取按钮键
		  var $answer = $("#replyButton");
		  $toggleBtn.click(function(){
		      if($category.is(":visible")){
			      $category.hide();
			  }else{
			      $category.show();
				  $answer.click(function(){
			          $category.hide();
			          return false;          //超链接不跳转
		      })
			      }
			  return false;          //超链接不跳转
		  })
	  })
      
    